# Formulário de Cadastro

Projeto de formulário desenvolvido com **HTML5** e **CSS3**, criado para praticar estrutura de páginas, formulários e estilização responsiva.

## Demonstração

O projeto pode ser publicado gratuitamente pelo **GitHub Pages**.

## Tecnologias utilizadas

- HTML5
- CSS3
- Git e GitHub

## Funcionalidades

- Campo de nome completo
- Validação de e-mail
- Data de nascimento
- Telefone
- Senha com quantidade mínima de caracteres
- Seleção de curso
- Seleção de turno
- Áreas de interesse
- Upload de currículo em PDF
- Campos de texto
- Aceite dos termos de uso
- Mensagem visual de envio
- Layout responsivo para telas menores

## Estrutura do projeto

```text
formulario-cadastro/
├── assets/
│   └── images/
│       └── logo.png
├── css/
│   └── style.css
├── index.html
├── .gitignore
└── README.md
```

## Como executar

1. Baixe ou clone este repositório.
2. Abra a pasta do projeto no VS Code.
3. Abra o arquivo `index.html` no navegador.

Não é necessário JavaScript ou servidor local para visualizar a página.

## Observação

Este é um projeto front-end de demonstração. O formulário utiliza validações nativas do HTML e a mensagem de sucesso é exibida visualmente após o envio. Não existe um backend conectado para armazenar os dados.

## Autor

Projeto desenvolvido para estudos e composição de portfólio de desenvolvimento web.
